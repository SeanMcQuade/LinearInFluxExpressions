function [neg_rows_in_col] = find_neg_rows_in_column(Current_col)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
outputArg1 = inputArg1;
outputArg2 = inputArg2;
end

